export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBWYWq14esejLNJ4Ls77sbwOHVIuTsqvh4",
    authDomain: "ionic-auth-example-862b1.firebaseapp.com",
    projectId: "ionic-auth-example-862b1",
    storageBucket: "ionic-auth-example-862b1.appspot.com",
    messagingSenderId: "714991366381",
    appId: "1:714991366381:web:d19a236679a16f98bfdce4",
    measurementId: "G-69TE695X6K"
  }
};
