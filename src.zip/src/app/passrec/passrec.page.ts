import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passrec',
  templateUrl: './passrec.page.html',
  styleUrls: ['./passrec.page.scss'],
})
export class PassrecPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
