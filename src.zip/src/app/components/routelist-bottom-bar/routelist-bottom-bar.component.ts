import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-routelist-bottom-bar',
  templateUrl: './routelist-bottom-bar.component.html',
  styleUrls: ['./routelist-bottom-bar.component.scss'],
})
export class RoutelistBottomBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
