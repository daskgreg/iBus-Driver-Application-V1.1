import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome2',
  templateUrl: './welcome2.page.html',
  styleUrls: ['./welcome2.page.scss'],
})
export class Welcome2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
