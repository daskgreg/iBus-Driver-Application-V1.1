import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createroute',
  templateUrl: './createroute.page.html',
  styleUrls: ['./createroute.page.scss'],
})
export class CreateroutePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
